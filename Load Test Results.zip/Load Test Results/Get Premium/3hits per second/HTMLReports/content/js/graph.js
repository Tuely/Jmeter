/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
    $(".portlet-header").css("cursor", "auto");
});

var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

// Fixes time stamps
function fixTimeStamps(series, offset){
    $.each(series, function(index, item) {
        $.each(item.data, function(index, coord) {
            coord[0] += offset;
        });
    });
}

// Check if the specified jquery object is a graph
function isGraph(object){
    return object.data('plot') !== undefined;
}

/**
 * Export graph to a PNG
 */
function exportToPNG(graphName, target) {
    var plot = $("#"+graphName).data('plot');
    var flotCanvas = plot.getCanvas();
    var image = flotCanvas.toDataURL();
    image = image.replace("image/png", "image/octet-stream");
    
    var downloadAttrSupported = ("download" in document.createElement("a"));
    if(downloadAttrSupported === true) {
        target.download = graphName + ".png";
        target.href = image;
    }
    else {
        document.location.href = image;
    }
    
}

// Override the specified graph options to fit the requirements of an overview
function prepareOverviewOptions(graphOptions){
    var overviewOptions = {
        series: {
            shadowSize: 0,
            lines: {
                lineWidth: 1
            },
            points: {
                // Show points on overview only when linked graph does not show
                // lines
                show: getProperty('series.lines.show', graphOptions) == false,
                radius : 1
            }
        },
        xaxis: {
            ticks: 2,
            axisLabel: null
        },
        yaxis: {
            ticks: 2,
            axisLabel: null
        },
        legend: {
            show: false,
            container: null
        },
        grid: {
            hoverable: false
        },
        tooltip: false
    };
    return $.extend(true, {}, graphOptions, overviewOptions);
}

// Force axes boundaries using graph extra options
function prepareOptions(options, data) {
    options.canvas = true;
    var extraOptions = data.extraOptions;
    if(extraOptions !== undefined){
        var xOffset = options.xaxis.mode === "time" ? 3600000 : 0;
        var yOffset = options.yaxis.mode === "time" ? 3600000 : 0;

        if(!isNaN(extraOptions.minX))
        	options.xaxis.min = parseFloat(extraOptions.minX) + xOffset;
        
        if(!isNaN(extraOptions.maxX))
        	options.xaxis.max = parseFloat(extraOptions.maxX) + xOffset;
        
        if(!isNaN(extraOptions.minY))
        	options.yaxis.min = parseFloat(extraOptions.minY) + yOffset;
        
        if(!isNaN(extraOptions.maxY))
        	options.yaxis.max = parseFloat(extraOptions.maxY) + yOffset;
    }
}

// Filter, mark series and sort data
/**
 * @param data
 * @param noMatchColor if defined and true, series.color are not matched with index
 */
function prepareSeries(data, noMatchColor){
    var result = data.result;

    // Keep only series when needed
    if(seriesFilter && (!filtersOnlySampleSeries || result.supportsControllersDiscrimination)){
        // Insensitive case matching
        var regexp = new RegExp(seriesFilter, 'i');
        result.series = $.grep(result.series, function(series, index){
            return regexp.test(series.label);
        });
    }

    // Keep only controllers series when supported and needed
    if(result.supportsControllersDiscrimination && showControllersOnly){
        result.series = $.grep(result.series, function(series, index){
            return series.isController;
        });
    }

    // Sort data and mark series
    $.each(result.series, function(index, series) {
        series.data.sort(compareByXCoordinate);
        if(!(noMatchColor && noMatchColor===true)) {
	        series.color = index;
	    }
    });
}

// Set the zoom on the specified plot object
function zoomPlot(plot, xmin, xmax, ymin, ymax){
    var axes = plot.getAxes();
    // Override axes min and max options
    $.extend(true, axes, {
        xaxis: {
            options : { min: xmin, max: xmax }
        },
        yaxis: {
            options : { min: ymin, max: ymax }
        }
    });

    // Redraw the plot
    plot.setupGrid();
    plot.draw();
}

// Prepares DOM items to add zoom function on the specified graph
function setGraphZoomable(graphSelector, overviewSelector){
    var graph = $(graphSelector);
    var overview = $(overviewSelector);

    // Ignore mouse down event
    graph.bind("mousedown", function() { return false; });
    overview.bind("mousedown", function() { return false; });

    // Zoom on selection
    graph.bind("plotselected", function (event, ranges) {
        // clamp the zooming to prevent infinite zoom
        if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
            ranges.xaxis.to = ranges.xaxis.from + 0.00001;
        }
        if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
            ranges.yaxis.to = ranges.yaxis.from + 0.00001;
        }

        // Do the zooming
        var plot = graph.data('plot');
        zoomPlot(plot, ranges.xaxis.from, ranges.xaxis.to, ranges.yaxis.from, ranges.yaxis.to);
        plot.clearSelection();

        // Synchronize overview selection
        overview.data('plot').setSelection(ranges, true);
    });

    // Zoom linked graph on overview selection
    overview.bind("plotselected", function (event, ranges) {
        graph.data('plot').setSelection(ranges);
    });

    // Reset linked graph zoom when reseting overview selection
    overview.bind("plotunselected", function () {
        var overviewAxes = overview.data('plot').getAxes();
        zoomPlot(graph.data('plot'), overviewAxes.xaxis.min, overviewAxes.xaxis.max, overviewAxes.yaxis.min, overviewAxes.yaxis.max);
    });
}

var responseTimePercentilesInfos = {
        data: {"result": {"minY": 4908.0, "minX": 0.0, "maxY": 210536.0, "series": [{"data": [[0.0, 4908.0], [0.1, 4908.0], [0.2, 4908.0], [0.3, 4908.0], [0.4, 60789.0], [0.5, 60789.0], [0.6, 60789.0], [0.7, 77060.0], [0.8, 77060.0], [0.9, 77060.0], [1.0, 78695.0], [1.1, 78695.0], [1.2, 78695.0], [1.3, 78695.0], [1.4, 79133.0], [1.5, 79133.0], [1.6, 79133.0], [1.7, 79136.0], [1.8, 79136.0], [1.9, 79136.0], [2.0, 79184.0], [2.1, 79184.0], [2.2, 79184.0], [2.3, 79184.0], [2.4, 79728.0], [2.5, 79728.0], [2.6, 79728.0], [2.7, 80225.0], [2.8, 80225.0], [2.9, 80225.0], [3.0, 80305.0], [3.1, 80305.0], [3.2, 80305.0], [3.3, 80305.0], [3.4, 81438.0], [3.5, 81438.0], [3.6, 81438.0], [3.7, 81450.0], [3.8, 81450.0], [3.9, 81450.0], [4.0, 82775.0], [4.1, 82775.0], [4.2, 82775.0], [4.3, 82775.0], [4.4, 82944.0], [4.5, 82944.0], [4.6, 82944.0], [4.7, 82975.0], [4.8, 82975.0], [4.9, 82975.0], [5.0, 83094.0], [5.1, 83094.0], [5.2, 83094.0], [5.3, 83094.0], [5.4, 83097.0], [5.5, 83097.0], [5.6, 83097.0], [5.7, 83292.0], [5.8, 83292.0], [5.9, 83292.0], [6.0, 83492.0], [6.1, 83492.0], [6.2, 83492.0], [6.3, 83492.0], [6.4, 84058.0], [6.5, 84058.0], [6.6, 84058.0], [6.7, 84177.0], [6.8, 84177.0], [6.9, 84177.0], [7.0, 84249.0], [7.1, 84249.0], [7.2, 84249.0], [7.3, 84249.0], [7.4, 84509.0], [7.5, 84509.0], [7.6, 84509.0], [7.7, 84511.0], [7.8, 84511.0], [7.9, 84511.0], [8.0, 84882.0], [8.1, 84882.0], [8.2, 84882.0], [8.3, 84882.0], [8.4, 84941.0], [8.5, 84941.0], [8.6, 84941.0], [8.7, 85286.0], [8.8, 85286.0], [8.9, 85286.0], [9.0, 85480.0], [9.1, 85480.0], [9.2, 85480.0], [9.3, 85480.0], [9.4, 85797.0], [9.5, 85797.0], [9.6, 85797.0], [9.7, 85978.0], [9.8, 85978.0], [9.9, 85978.0], [10.0, 86241.0], [10.1, 86241.0], [10.2, 86241.0], [10.3, 86241.0], [10.4, 87076.0], [10.5, 87076.0], [10.6, 87076.0], [10.7, 87117.0], [10.8, 87117.0], [10.9, 87117.0], [11.0, 87117.0], [11.1, 87297.0], [11.2, 87297.0], [11.3, 87297.0], [11.4, 88623.0], [11.5, 88623.0], [11.6, 88623.0], [11.7, 88929.0], [11.8, 88929.0], [11.9, 88929.0], [12.0, 88929.0], [12.1, 89068.0], [12.2, 89068.0], [12.3, 89068.0], [12.4, 89281.0], [12.5, 89281.0], [12.6, 89281.0], [12.7, 89343.0], [12.8, 89343.0], [12.9, 89343.0], [13.0, 89343.0], [13.1, 89344.0], [13.2, 89344.0], [13.3, 89344.0], [13.4, 89358.0], [13.5, 89358.0], [13.6, 89358.0], [13.7, 89382.0], [13.8, 89382.0], [13.9, 89382.0], [14.0, 89382.0], [14.1, 89412.0], [14.2, 89412.0], [14.3, 89412.0], [14.4, 90495.0], [14.5, 90495.0], [14.6, 90495.0], [14.7, 90505.0], [14.8, 90505.0], [14.9, 90505.0], [15.0, 90505.0], [15.1, 90919.0], [15.2, 90919.0], [15.3, 90919.0], [15.4, 91001.0], [15.5, 91001.0], [15.6, 91001.0], [15.7, 91228.0], [15.8, 91228.0], [15.9, 91228.0], [16.0, 91228.0], [16.1, 91447.0], [16.2, 91447.0], [16.3, 91447.0], [16.4, 91647.0], [16.5, 91647.0], [16.6, 91647.0], [16.7, 91682.0], [16.8, 91682.0], [16.9, 91682.0], [17.0, 91682.0], [17.1, 91768.0], [17.2, 91768.0], [17.3, 91768.0], [17.4, 92033.0], [17.5, 92033.0], [17.6, 92033.0], [17.7, 92036.0], [17.8, 92036.0], [17.9, 92036.0], [18.0, 92036.0], [18.1, 92112.0], [18.2, 92112.0], [18.3, 92112.0], [18.4, 92164.0], [18.5, 92164.0], [18.6, 92164.0], [18.7, 92191.0], [18.8, 92191.0], [18.9, 92191.0], [19.0, 92219.0], [19.1, 92219.0], [19.2, 92219.0], [19.3, 92219.0], [19.4, 92693.0], [19.5, 92693.0], [19.6, 92693.0], [19.7, 92743.0], [19.8, 92743.0], [19.9, 92743.0], [20.0, 92765.0], [20.1, 92765.0], [20.2, 92765.0], [20.3, 92765.0], [20.4, 93072.0], [20.5, 93072.0], [20.6, 93072.0], [20.7, 93093.0], [20.8, 93093.0], [20.9, 93093.0], [21.0, 93380.0], [21.1, 93380.0], [21.2, 93380.0], [21.3, 93380.0], [21.4, 93475.0], [21.5, 93475.0], [21.6, 93475.0], [21.7, 93499.0], [21.8, 93499.0], [21.9, 93499.0], [22.0, 93609.0], [22.1, 93609.0], [22.2, 93609.0], [22.3, 93609.0], [22.4, 93756.0], [22.5, 93756.0], [22.6, 93756.0], [22.7, 93838.0], [22.8, 93838.0], [22.9, 93838.0], [23.0, 93962.0], [23.1, 93962.0], [23.2, 93962.0], [23.3, 93962.0], [23.4, 94424.0], [23.5, 94424.0], [23.6, 94424.0], [23.7, 94629.0], [23.8, 94629.0], [23.9, 94629.0], [24.0, 94735.0], [24.1, 94735.0], [24.2, 94735.0], [24.3, 94735.0], [24.4, 94793.0], [24.5, 94793.0], [24.6, 94793.0], [24.7, 95131.0], [24.8, 95131.0], [24.9, 95131.0], [25.0, 95266.0], [25.1, 95266.0], [25.2, 95266.0], [25.3, 95266.0], [25.4, 95546.0], [25.5, 95546.0], [25.6, 95546.0], [25.7, 95546.0], [25.8, 95546.0], [25.9, 95546.0], [26.0, 95744.0], [26.1, 95744.0], [26.2, 95744.0], [26.3, 95744.0], [26.4, 96001.0], [26.5, 96001.0], [26.6, 96001.0], [26.7, 96039.0], [26.8, 96039.0], [26.9, 96039.0], [27.0, 96206.0], [27.1, 96206.0], [27.2, 96206.0], [27.3, 96206.0], [27.4, 96279.0], [27.5, 96279.0], [27.6, 96279.0], [27.7, 96358.0], [27.8, 96358.0], [27.9, 96358.0], [28.0, 96425.0], [28.1, 96425.0], [28.2, 96425.0], [28.3, 96425.0], [28.4, 96507.0], [28.5, 96507.0], [28.6, 96507.0], [28.7, 96684.0], [28.8, 96684.0], [28.9, 96684.0], [29.0, 96897.0], [29.1, 96897.0], [29.2, 96897.0], [29.3, 96897.0], [29.4, 96975.0], [29.5, 96975.0], [29.6, 96975.0], [29.7, 97034.0], [29.8, 97034.0], [29.9, 97034.0], [30.0, 97050.0], [30.1, 97050.0], [30.2, 97050.0], [30.3, 97050.0], [30.4, 97150.0], [30.5, 97150.0], [30.6, 97150.0], [30.7, 97217.0], [30.8, 97217.0], [30.9, 97217.0], [31.0, 97299.0], [31.1, 97299.0], [31.2, 97299.0], [31.3, 97299.0], [31.4, 97428.0], [31.5, 97428.0], [31.6, 97428.0], [31.7, 97494.0], [31.8, 97494.0], [31.9, 97494.0], [32.0, 97617.0], [32.1, 97617.0], [32.2, 97617.0], [32.3, 97617.0], [32.4, 97642.0], [32.5, 97642.0], [32.6, 97642.0], [32.7, 97647.0], [32.8, 97647.0], [32.9, 97647.0], [33.0, 97897.0], [33.1, 97897.0], [33.2, 97897.0], [33.3, 97897.0], [33.4, 97914.0], [33.5, 97914.0], [33.6, 97914.0], [33.7, 98296.0], [33.8, 98296.0], [33.9, 98296.0], [34.0, 98496.0], [34.1, 98496.0], [34.2, 98496.0], [34.3, 98496.0], [34.4, 98664.0], [34.5, 98664.0], [34.6, 98664.0], [34.7, 98666.0], [34.8, 98666.0], [34.9, 98666.0], [35.0, 98689.0], [35.1, 98689.0], [35.2, 98689.0], [35.3, 98689.0], [35.4, 98764.0], [35.5, 98764.0], [35.6, 98764.0], [35.7, 99062.0], [35.8, 99062.0], [35.9, 99062.0], [36.0, 99096.0], [36.1, 99096.0], [36.2, 99096.0], [36.3, 99096.0], [36.4, 99155.0], [36.5, 99155.0], [36.6, 99155.0], [36.7, 99364.0], [36.8, 99364.0], [36.9, 99364.0], [37.0, 99487.0], [37.1, 99487.0], [37.2, 99487.0], [37.3, 99487.0], [37.4, 99499.0], [37.5, 99499.0], [37.6, 99499.0], [37.7, 99539.0], [37.8, 99539.0], [37.9, 99539.0], [38.0, 99581.0], [38.1, 99581.0], [38.2, 99581.0], [38.3, 99581.0], [38.4, 99654.0], [38.5, 99654.0], [38.6, 99654.0], [38.7, 99746.0], [38.8, 99746.0], [38.9, 99746.0], [39.0, 99746.0], [39.1, 100501.0], [39.2, 100501.0], [39.3, 100501.0], [39.4, 100651.0], [39.5, 100651.0], [39.6, 100651.0], [39.7, 100966.0], [39.8, 100966.0], [39.9, 100966.0], [40.0, 100966.0], [40.1, 101137.0], [40.2, 101137.0], [40.3, 101137.0], [40.4, 101158.0], [40.5, 101158.0], [40.6, 101158.0], [40.7, 101370.0], [40.8, 101370.0], [40.9, 101370.0], [41.0, 101370.0], [41.1, 102806.0], [41.2, 102806.0], [41.3, 102806.0], [41.4, 103156.0], [41.5, 103156.0], [41.6, 103156.0], [41.7, 103703.0], [41.8, 103703.0], [41.9, 103703.0], [42.0, 103703.0], [42.1, 104757.0], [42.2, 104757.0], [42.3, 104757.0], [42.4, 104950.0], [42.5, 104950.0], [42.6, 104950.0], [42.7, 104974.0], [42.8, 104974.0], [42.9, 104974.0], [43.0, 104974.0], [43.1, 105027.0], [43.2, 105027.0], [43.3, 105027.0], [43.4, 108369.0], [43.5, 108369.0], [43.6, 108369.0], [43.7, 110332.0], [43.8, 110332.0], [43.9, 110332.0], [44.0, 110332.0], [44.1, 114298.0], [44.2, 114298.0], [44.3, 114298.0], [44.4, 114682.0], [44.5, 114682.0], [44.6, 114682.0], [44.7, 114893.0], [44.8, 114893.0], [44.9, 114893.0], [45.0, 114893.0], [45.1, 115050.0], [45.2, 115050.0], [45.3, 115050.0], [45.4, 115153.0], [45.5, 115153.0], [45.6, 115153.0], [45.7, 115640.0], [45.8, 115640.0], [45.9, 115640.0], [46.0, 115640.0], [46.1, 117539.0], [46.2, 117539.0], [46.3, 117539.0], [46.4, 118198.0], [46.5, 118198.0], [46.6, 118198.0], [46.7, 118414.0], [46.8, 118414.0], [46.9, 118414.0], [47.0, 118414.0], [47.1, 119782.0], [47.2, 119782.0], [47.3, 119782.0], [47.4, 119846.0], [47.5, 119846.0], [47.6, 119846.0], [47.7, 119891.0], [47.8, 119891.0], [47.9, 119891.0], [48.0, 119891.0], [48.1, 120192.0], [48.2, 120192.0], [48.3, 120192.0], [48.4, 120412.0], [48.5, 120412.0], [48.6, 120412.0], [48.7, 120539.0], [48.8, 120539.0], [48.9, 120539.0], [49.0, 120539.0], [49.1, 121085.0], [49.2, 121085.0], [49.3, 121085.0], [49.4, 121149.0], [49.5, 121149.0], [49.6, 121149.0], [49.7, 122279.0], [49.8, 122279.0], [49.9, 122279.0], [50.0, 122279.0], [50.1, 122360.0], [50.2, 122360.0], [50.3, 122360.0], [50.4, 122870.0], [50.5, 122870.0], [50.6, 122870.0], [50.7, 122940.0], [50.8, 122940.0], [50.9, 122940.0], [51.0, 122940.0], [51.1, 123118.0], [51.2, 123118.0], [51.3, 123118.0], [51.4, 124221.0], [51.5, 124221.0], [51.6, 124221.0], [51.7, 124293.0], [51.8, 124293.0], [51.9, 124293.0], [52.0, 124293.0], [52.1, 124541.0], [52.2, 124541.0], [52.3, 124541.0], [52.4, 124915.0], [52.5, 124915.0], [52.6, 124915.0], [52.7, 125495.0], [52.8, 125495.0], [52.9, 125495.0], [53.0, 125495.0], [53.1, 125542.0], [53.2, 125542.0], [53.3, 125542.0], [53.4, 125637.0], [53.5, 125637.0], [53.6, 125637.0], [53.7, 125959.0], [53.8, 125959.0], [53.9, 125959.0], [54.0, 125959.0], [54.1, 126405.0], [54.2, 126405.0], [54.3, 126405.0], [54.4, 126834.0], [54.5, 126834.0], [54.6, 126834.0], [54.7, 127154.0], [54.8, 127154.0], [54.9, 127154.0], [55.0, 127154.0], [55.1, 128023.0], [55.2, 128023.0], [55.3, 128023.0], [55.4, 128417.0], [55.5, 128417.0], [55.6, 128417.0], [55.7, 128527.0], [55.8, 128527.0], [55.9, 128527.0], [56.0, 128527.0], [56.1, 129083.0], [56.2, 129083.0], [56.3, 129083.0], [56.4, 129410.0], [56.5, 129410.0], [56.6, 129410.0], [56.7, 129506.0], [56.8, 129506.0], [56.9, 129506.0], [57.0, 129506.0], [57.1, 130494.0], [57.2, 130494.0], [57.3, 130494.0], [57.4, 130528.0], [57.5, 130528.0], [57.6, 130528.0], [57.7, 130841.0], [57.8, 130841.0], [57.9, 130841.0], [58.0, 130841.0], [58.1, 130923.0], [58.2, 130923.0], [58.3, 130923.0], [58.4, 131322.0], [58.5, 131322.0], [58.6, 131322.0], [58.7, 131402.0], [58.8, 131402.0], [58.9, 131402.0], [59.0, 131402.0], [59.1, 131489.0], [59.2, 131489.0], [59.3, 131489.0], [59.4, 132887.0], [59.5, 132887.0], [59.6, 132887.0], [59.7, 133619.0], [59.8, 133619.0], [59.9, 133619.0], [60.0, 133619.0], [60.1, 133690.0], [60.2, 133690.0], [60.3, 133690.0], [60.4, 134108.0], [60.5, 134108.0], [60.6, 134108.0], [60.7, 135385.0], [60.8, 135385.0], [60.9, 135385.0], [61.0, 135385.0], [61.1, 135716.0], [61.2, 135716.0], [61.3, 135716.0], [61.4, 135721.0], [61.5, 135721.0], [61.6, 135721.0], [61.7, 135972.0], [61.8, 135972.0], [61.9, 135972.0], [62.0, 135972.0], [62.1, 136717.0], [62.2, 136717.0], [62.3, 136717.0], [62.4, 136731.0], [62.5, 136731.0], [62.6, 136731.0], [62.7, 137001.0], [62.8, 137001.0], [62.9, 137001.0], [63.0, 137001.0], [63.1, 137243.0], [63.2, 137243.0], [63.3, 137243.0], [63.4, 137502.0], [63.5, 137502.0], [63.6, 137502.0], [63.7, 137577.0], [63.8, 137577.0], [63.9, 137577.0], [64.0, 137577.0], [64.1, 137885.0], [64.2, 137885.0], [64.3, 137885.0], [64.4, 138057.0], [64.5, 138057.0], [64.6, 138057.0], [64.7, 138257.0], [64.8, 138257.0], [64.9, 138257.0], [65.0, 138257.0], [65.1, 138733.0], [65.2, 138733.0], [65.3, 138733.0], [65.4, 138946.0], [65.5, 138946.0], [65.6, 138946.0], [65.7, 139665.0], [65.8, 139665.0], [65.9, 139665.0], [66.0, 139665.0], [66.1, 140522.0], [66.2, 140522.0], [66.3, 140522.0], [66.4, 140680.0], [66.5, 140680.0], [66.6, 140680.0], [66.7, 142276.0], [66.8, 142276.0], [66.9, 142276.0], [67.0, 142276.0], [67.1, 142294.0], [67.2, 142294.0], [67.3, 142294.0], [67.4, 142462.0], [67.5, 142462.0], [67.6, 142462.0], [67.7, 142607.0], [67.8, 142607.0], [67.9, 142607.0], [68.0, 142607.0], [68.1, 142652.0], [68.2, 142652.0], [68.3, 142652.0], [68.4, 143170.0], [68.5, 143170.0], [68.6, 143170.0], [68.7, 144122.0], [68.8, 144122.0], [68.9, 144122.0], [69.0, 144122.0], [69.1, 144406.0], [69.2, 144406.0], [69.3, 144406.0], [69.4, 144719.0], [69.5, 144719.0], [69.6, 144719.0], [69.7, 145661.0], [69.8, 145661.0], [69.9, 145661.0], [70.0, 145661.0], [70.1, 145900.0], [70.2, 145900.0], [70.3, 145900.0], [70.4, 146097.0], [70.5, 146097.0], [70.6, 146097.0], [70.7, 146229.0], [70.8, 146229.0], [70.9, 146229.0], [71.0, 146229.0], [71.1, 146671.0], [71.2, 146671.0], [71.3, 146671.0], [71.4, 146829.0], [71.5, 146829.0], [71.6, 146829.0], [71.7, 147415.0], [71.8, 147415.0], [71.9, 147415.0], [72.0, 147415.0], [72.1, 147728.0], [72.2, 147728.0], [72.3, 147728.0], [72.4, 149118.0], [72.5, 149118.0], [72.6, 149118.0], [72.7, 149321.0], [72.8, 149321.0], [72.9, 149321.0], [73.0, 149321.0], [73.1, 149404.0], [73.2, 149404.0], [73.3, 149404.0], [73.4, 149844.0], [73.5, 149844.0], [73.6, 149844.0], [73.7, 150645.0], [73.8, 150645.0], [73.9, 150645.0], [74.0, 150645.0], [74.1, 151890.0], [74.2, 151890.0], [74.3, 151890.0], [74.4, 153185.0], [74.5, 153185.0], [74.6, 153185.0], [74.7, 153411.0], [74.8, 153411.0], [74.9, 153411.0], [75.0, 153411.0], [75.1, 153948.0], [75.2, 153948.0], [75.3, 153948.0], [75.4, 154658.0], [75.5, 154658.0], [75.6, 154658.0], [75.7, 155514.0], [75.8, 155514.0], [75.9, 155514.0], [76.0, 155514.0], [76.1, 156552.0], [76.2, 156552.0], [76.3, 156552.0], [76.4, 156650.0], [76.5, 156650.0], [76.6, 156650.0], [76.7, 156705.0], [76.8, 156705.0], [76.9, 156705.0], [77.0, 157086.0], [77.1, 157086.0], [77.2, 157086.0], [77.3, 157086.0], [77.4, 157240.0], [77.5, 157240.0], [77.6, 157240.0], [77.7, 157362.0], [77.8, 157362.0], [77.9, 157362.0], [78.0, 157410.0], [78.1, 157410.0], [78.2, 157410.0], [78.3, 157410.0], [78.4, 157597.0], [78.5, 157597.0], [78.6, 157597.0], [78.7, 158124.0], [78.8, 158124.0], [78.9, 158124.0], [79.0, 158643.0], [79.1, 158643.0], [79.2, 158643.0], [79.3, 158643.0], [79.4, 158894.0], [79.5, 158894.0], [79.6, 158894.0], [79.7, 159153.0], [79.8, 159153.0], [79.9, 159153.0], [80.0, 159163.0], [80.1, 159163.0], [80.2, 159163.0], [80.3, 159163.0], [80.4, 160027.0], [80.5, 160027.0], [80.6, 160027.0], [80.7, 160535.0], [80.8, 160535.0], [80.9, 160535.0], [81.0, 160781.0], [81.1, 160781.0], [81.2, 160781.0], [81.3, 160781.0], [81.4, 161382.0], [81.5, 161382.0], [81.6, 161382.0], [81.7, 161385.0], [81.8, 161385.0], [81.9, 161385.0], [82.0, 161551.0], [82.1, 161551.0], [82.2, 161551.0], [82.3, 161551.0], [82.4, 161888.0], [82.5, 161888.0], [82.6, 161888.0], [82.7, 162193.0], [82.8, 162193.0], [82.9, 162193.0], [83.0, 162400.0], [83.1, 162400.0], [83.2, 162400.0], [83.3, 162400.0], [83.4, 162458.0], [83.5, 162458.0], [83.6, 162458.0], [83.7, 163331.0], [83.8, 163331.0], [83.9, 163331.0], [84.0, 165058.0], [84.1, 165058.0], [84.2, 165058.0], [84.3, 165058.0], [84.4, 165349.0], [84.5, 165349.0], [84.6, 165349.0], [84.7, 166991.0], [84.8, 166991.0], [84.9, 166991.0], [85.0, 168131.0], [85.1, 168131.0], [85.2, 168131.0], [85.3, 168131.0], [85.4, 169127.0], [85.5, 169127.0], [85.6, 169127.0], [85.7, 170297.0], [85.8, 170297.0], [85.9, 170297.0], [86.0, 171059.0], [86.1, 171059.0], [86.2, 171059.0], [86.3, 171059.0], [86.4, 172208.0], [86.5, 172208.0], [86.6, 172208.0], [86.7, 173385.0], [86.8, 173385.0], [86.9, 173385.0], [87.0, 173825.0], [87.1, 173825.0], [87.2, 173825.0], [87.3, 173825.0], [87.4, 174087.0], [87.5, 174087.0], [87.6, 174087.0], [87.7, 174744.0], [87.8, 174744.0], [87.9, 174744.0], [88.0, 175480.0], [88.1, 175480.0], [88.2, 175480.0], [88.3, 175480.0], [88.4, 177092.0], [88.5, 177092.0], [88.6, 177092.0], [88.7, 177784.0], [88.8, 177784.0], [88.9, 177784.0], [89.0, 180212.0], [89.1, 180212.0], [89.2, 180212.0], [89.3, 180212.0], [89.4, 180414.0], [89.5, 180414.0], [89.6, 180414.0], [89.7, 181211.0], [89.8, 181211.0], [89.9, 181211.0], [90.0, 181741.0], [90.1, 181741.0], [90.2, 181741.0], [90.3, 181741.0], [90.4, 184003.0], [90.5, 184003.0], [90.6, 184003.0], [90.7, 184209.0], [90.8, 184209.0], [90.9, 184209.0], [91.0, 185003.0], [91.1, 185003.0], [91.2, 185003.0], [91.3, 185003.0], [91.4, 186333.0], [91.5, 186333.0], [91.6, 186333.0], [91.7, 186528.0], [91.8, 186528.0], [91.9, 186528.0], [92.0, 187249.0], [92.1, 187249.0], [92.2, 187249.0], [92.3, 187249.0], [92.4, 187302.0], [92.5, 187302.0], [92.6, 187302.0], [92.7, 187941.0], [92.8, 187941.0], [92.9, 187941.0], [93.0, 189183.0], [93.1, 189183.0], [93.2, 189183.0], [93.3, 189183.0], [93.4, 189213.0], [93.5, 189213.0], [93.6, 189213.0], [93.7, 190712.0], [93.8, 190712.0], [93.9, 190712.0], [94.0, 191147.0], [94.1, 191147.0], [94.2, 191147.0], [94.3, 191147.0], [94.4, 196212.0], [94.5, 196212.0], [94.6, 196212.0], [94.7, 196352.0], [94.8, 196352.0], [94.9, 196352.0], [95.0, 196745.0], [95.1, 196745.0], [95.2, 196745.0], [95.3, 196745.0], [95.4, 196924.0], [95.5, 196924.0], [95.6, 196924.0], [95.7, 197215.0], [95.8, 197215.0], [95.9, 197215.0], [96.0, 198039.0], [96.1, 198039.0], [96.2, 198039.0], [96.3, 198039.0], [96.4, 199171.0], [96.5, 199171.0], [96.6, 199171.0], [96.7, 201348.0], [96.8, 201348.0], [96.9, 201348.0], [97.0, 203210.0], [97.1, 203210.0], [97.2, 203210.0], [97.3, 203210.0], [97.4, 203590.0], [97.5, 203590.0], [97.6, 203590.0], [97.7, 204307.0], [97.8, 204307.0], [97.9, 204307.0], [98.0, 206636.0], [98.1, 206636.0], [98.2, 206636.0], [98.3, 206636.0], [98.4, 208221.0], [98.5, 208221.0], [98.6, 208221.0], [98.7, 208226.0], [98.8, 208226.0], [98.9, 208226.0], [99.0, 210043.0], [99.1, 210043.0], [99.2, 210043.0], [99.3, 210043.0], [99.4, 210345.0], [99.5, 210345.0], [99.6, 210345.0], [99.7, 210536.0], [99.8, 210536.0], [99.9, 210536.0]], "isOverall": false, "label": "Get Premium", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 4900.0, "maxY": 4.0, "series": [{"data": [[133600.0, 2.0], [162400.0, 2.0], [131300.0, 1.0], [144100.0, 1.0], [163300.0, 1.0], [168100.0, 1.0], [177700.0, 1.0], [187300.0, 1.0], [196900.0, 1.0], [80300.0, 1.0], [85900.0, 1.0], [82700.0, 1.0], [93900.0, 1.0], [97100.0, 1.0], [95500.0, 2.0], [94700.0, 2.0], [97900.0, 1.0], [96300.0, 1.0], [98700.0, 1.0], [101100.0, 2.0], [99500.0, 2.0], [108300.0, 1.0], [121100.0, 1.0], [125900.0, 1.0], [137000.0, 1.0], [146600.0, 1.0], [149800.0, 1.0], [154600.0, 1.0], [175400.0, 1.0], [172200.0, 1.0], [180200.0, 1.0], [177000.0, 1.0], [173800.0, 1.0], [185000.0, 1.0], [196200.0, 1.0], [145900.0, 1.0], [149100.0, 1.0], [155500.0, 1.0], [153900.0, 1.0], [174700.0, 1.0], [189100.0, 1.0], [190700.0, 1.0], [203500.0, 1.0], [77000.0, 1.0], [80200.0, 1.0], [78600.0, 1.0], [83400.0, 1.0], [84200.0, 1.0], [89000.0, 1.0], [91400.0, 1.0], [93800.0, 1.0], [92200.0, 1.0], [93000.0, 2.0], [97800.0, 1.0], [96200.0, 2.0], [97000.0, 2.0], [94600.0, 1.0], [98600.0, 3.0], [99400.0, 2.0], [105000.0, 1.0], [114600.0, 1.0], [121000.0, 1.0], [124200.0, 2.0], [129000.0, 1.0], [137200.0, 1.0], [146800.0, 1.0], [174000.0, 1.0], [180400.0, 1.0], [198000.0, 1.0], [149300.0, 1.0], [147700.0, 1.0], [157300.0, 1.0], [160500.0, 1.0], [162100.0, 1.0], [165300.0, 1.0], [166900.0, 1.0], [173300.0, 1.0], [4900.0, 1.0], [84100.0, 1.0], [85700.0, 1.0], [84900.0, 1.0], [88900.0, 1.0], [93700.0, 1.0], [92100.0, 3.0], [90500.0, 1.0], [96900.0, 1.0], [100900.0, 1.0], [99300.0, 1.0], [104900.0, 2.0], [120100.0, 1.0], [124900.0, 1.0], [130500.0, 1.0], [142200.0, 2.0], [140600.0, 1.0], [153400.0, 1.0], [151800.0, 1.0], [156600.0, 1.0], [171000.0, 1.0], [136700.0, 2.0], [143100.0, 1.0], [144700.0, 1.0], [159100.0, 2.0], [157500.0, 1.0], [160700.0, 1.0], [187900.0, 1.0], [186300.0, 1.0], [191100.0, 1.0], [199100.0, 1.0], [210300.0, 1.0], [84800.0, 1.0], [84000.0, 1.0], [83200.0, 1.0], [87200.0, 1.0], [90400.0, 1.0], [92000.0, 2.0], [91200.0, 1.0], [93600.0, 1.0], [94400.0, 1.0], [96800.0, 1.0], [97600.0, 3.0], [95200.0, 1.0], [96000.0, 2.0], [98400.0, 1.0], [118400.0, 1.0], [126400.0, 1.0], [125600.0, 1.0], [128000.0, 1.0], [130400.0, 1.0], [132800.0, 1.0], [142400.0, 1.0], [145600.0, 1.0], [160000.0, 1.0], [184000.0, 1.0], [187200.0, 1.0], [203200.0, 1.0], [135300.0, 1.0], [186500.0, 1.0], [181700.0, 1.0], [210500.0, 1.0], [79100.0, 3.0], [87100.0, 1.0], [92700.0, 2.0], [95100.0, 1.0], [99100.0, 1.0], [103100.0, 1.0], [104700.0, 1.0], [110300.0, 1.0], [117500.0, 1.0], [115100.0, 1.0], [122300.0, 1.0], [125500.0, 1.0], [123100.0, 1.0], [127100.0, 1.0], [129500.0, 1.0], [131400.0, 2.0], [137800.0, 1.0], [147400.0, 1.0], [142600.0, 2.0], [150600.0, 1.0], [158600.0, 1.0], [161800.0, 1.0], [157000.0, 1.0], [165000.0, 1.0], [184200.0, 1.0], [208200.0, 2.0], [206600.0, 1.0], [138700.0, 1.0], [153100.0, 1.0], [169100.0, 1.0], [196300.0, 1.0], [204300.0, 1.0], [60700.0, 1.0], [81400.0, 2.0], [85400.0, 1.0], [83000.0, 2.0], [87000.0, 1.0], [89400.0, 1.0], [86200.0, 1.0], [88600.0, 1.0], [91000.0, 1.0], [93400.0, 2.0], [92600.0, 1.0], [97400.0, 2.0], [98200.0, 1.0], [96600.0, 1.0], [100600.0, 1.0], [99000.0, 2.0], [114200.0, 1.0], [115000.0, 1.0], [119800.0, 2.0], [122200.0, 1.0], [125400.0, 1.0], [129400.0, 1.0], [138000.0, 1.0], [144400.0, 1.0], [139600.0, 1.0], [146000.0, 1.0], [158800.0, 1.0], [157200.0, 1.0], [181200.0, 1.0], [189200.0, 1.0], [197200.0, 1.0], [210000.0, 1.0], [138900.0, 1.0], [134100.0, 1.0], [135700.0, 2.0], [140500.0, 1.0], [161300.0, 2.0], [156500.0, 1.0], [158100.0, 1.0], [201300.0, 1.0], [79700.0, 1.0], [84500.0, 2.0], [82900.0, 2.0], [89300.0, 4.0], [90900.0, 1.0], [91700.0, 1.0], [93300.0, 1.0], [95700.0, 1.0], [96500.0, 1.0], [100500.0, 1.0], [101300.0, 1.0], [99700.0, 1.0], [103700.0, 1.0], [118100.0, 1.0], [120500.0, 1.0], [119700.0, 1.0], [124500.0, 1.0], [122900.0, 1.0], [128500.0, 1.0], [130900.0, 1.0], [138200.0, 1.0], [146200.0, 1.0], [149400.0, 1.0], [157400.0, 1.0], [170200.0, 1.0], [135900.0, 1.0], [137500.0, 2.0], [161500.0, 1.0], [156700.0, 1.0], [196700.0, 1.0], [85200.0, 1.0], [89200.0, 1.0], [91600.0, 2.0], [97200.0, 2.0], [96400.0, 1.0], [99600.0, 1.0], [102800.0, 1.0], [115600.0, 1.0], [114800.0, 1.0], [120400.0, 1.0], [122800.0, 1.0], [126800.0, 1.0], [128400.0, 1.0], [130800.0, 1.0]], "isOverall": false, "label": "Get Premium", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 210500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 300.0, "minX": 2.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 300.0, "series": [{"data": [[2.0, 300.0]], "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                },
                colors: ["#9ACD32", "yellow", "orange", "#FF6347"]                
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.5369189E12, "maxY": 100.0, "series": [{"data": [[1.53691902E12, 100.0], [1.53691932E12, 72.41379310344826], [1.53691914E12, 99.69999999999995], [1.53691896E12, 62.0], [1.53691926E12, 98.4626865671642], [1.5369189E12, 5.0], [1.53691938E12, 22.0], [1.5369192E12, 99.0]], "isOverall": false, "label": "Get Premium- concurrent user ", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.53691938E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 54305.5, "minX": 1.0, "maxY": 153408.70422535212, "series": [{"data": [[2.0, 92743.0], [3.0, 93093.0], [4.0, 104757.0], [5.0, 54305.5], [6.0, 92693.0], [7.0, 101158.0], [8.0, 97428.0], [9.0, 94629.0], [10.0, 96425.0], [11.0, 96684.0], [12.0, 94793.0], [13.0, 97617.0], [14.0, 97217.0], [15.0, 96507.0], [16.0, 93380.0], [17.0, 93072.0], [18.0, 96358.0], [19.0, 96279.0], [20.0, 99096.0], [21.0, 102806.0], [22.0, 99364.0], [23.0, 99581.0], [24.0, 97914.0], [25.0, 98664.0], [26.0, 97299.0], [27.0, 98296.0], [28.0, 97494.0], [29.0, 94735.0], [30.0, 95131.0], [31.0, 97050.0], [33.0, 96039.0], [32.0, 97034.0], [35.0, 96206.0], [34.0, 93609.0], [37.0, 95744.0], [36.0, 96001.0], [39.0, 92036.0], [38.0, 93475.0], [41.0, 92033.0], [40.0, 91228.0], [43.0, 92219.0], [42.0, 91768.0], [45.0, 88929.0], [44.0, 90919.0], [47.0, 90505.0], [46.0, 92191.0], [49.0, 92112.0], [48.0, 93838.0], [51.0, 90495.0], [50.0, 89344.0], [53.0, 89382.0], [52.0, 91647.0], [55.0, 87117.0], [54.0, 89281.0], [57.0, 86241.0], [56.0, 88623.0], [59.0, 81450.0], [58.0, 87297.0], [61.0, 79133.0], [60.0, 80305.0], [62.0, 68924.5], [63.0, 78695.0], [67.0, 83094.0], [66.0, 82775.0], [65.0, 79184.0], [64.0, 79728.0], [71.0, 104974.0], [70.0, 79136.0], [69.0, 99062.0], [68.0, 108369.0], [75.0, 95266.0], [74.0, 99654.0], [73.0, 80225.0], [72.0, 95546.0], [79.0, 95546.0], [78.0, 99487.0], [77.0, 99539.0], [76.0, 99746.0], [83.0, 101137.0], [82.0, 100651.0], [81.0, 98496.0], [80.0, 99155.0], [87.0, 93962.0], [86.0, 98764.0], [85.0, 101168.0], [91.0, 96975.0], [90.0, 97150.0], [89.0, 99499.0], [88.0, 100501.0], [95.0, 92164.0], [94.0, 97897.0], [93.0, 97647.0], [92.0, 97642.0], [99.0, 130391.43333333333], [98.0, 149546.125], [97.0, 92765.0], [96.0, 93499.0], [100.0, 153408.70422535212], [1.0, 105027.0]], "isOverall": false, "label": "Get Premium", "isController": false}, {"data": [[82.50333333333334, 126031.02999999987]], "isOverall": false, "label": "Get Premium-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 77.55, "minX": 1.5369189E12, "maxY": 14668.116666666667, "series": [{"data": [[1.53691902E12, 146.68333333333334], [1.53691932E12, 8507.55], [1.53691914E12, 14668.116666666667], [1.53691896E12, 146.68333333333334], [1.53691926E12, 9827.716666666667], [1.5369189E12, 146.68333333333334], [1.53691938E12, 6307.3], [1.5369192E12, 4253.8]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.53691902E12, 77.55], [1.53691932E12, 4497.55], [1.53691914E12, 7755.0], [1.53691896E12, 77.55], [1.53691926E12, 5195.85], [1.5369189E12, 77.55], [1.53691938E12, 3334.65], [1.5369192E12, 2248.95]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.53691938E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 4908.0, "minX": 1.5369189E12, "maxY": 160952.65000000005, "series": [{"data": [[1.53691902E12, 104950.0], [1.53691932E12, 96624.01724137933], [1.53691914E12, 160952.65000000005], [1.53691896E12, 60789.0], [1.53691926E12, 138099.25373134328], [1.5369189E12, 4908.0], [1.53691938E12, 96474.06976744186], [1.5369192E12, 87523.06896551723]], "isOverall": false, "label": "Get Premium", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.53691938E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 4908.0, "minX": 1.5369189E12, "maxY": 160949.06000000003, "series": [{"data": [[1.53691902E12, 104950.0], [1.53691932E12, 96623.63793103443], [1.53691914E12, 160949.06000000003], [1.53691896E12, 60789.0], [1.53691926E12, 138056.04477611944], [1.5369189E12, 4908.0], [1.53691938E12, 96473.53488372092], [1.5369192E12, 87522.62068965514]], "isOverall": false, "label": "Get Premium", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.53691938E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.5369189E12, "maxY": 159.37209302325584, "series": [{"data": [[1.53691902E12, 5.0], [1.53691932E12, 5.879310344827587], [1.53691914E12, 73.08999999999999], [1.53691896E12, 5.0], [1.53691926E12, 5.805970149253732], [1.5369189E12, 64.0], [1.53691938E12, 159.37209302325584], [1.5369192E12, 5.724137931034484]], "isOverall": false, "label": "Get Premium", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.53691938E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 4908.0, "minX": 1.5369189E12, "maxY": 210536.0, "series": [{"data": [[1.53691902E12, 104950.0], [1.53691932E12, 177092.0], [1.53691914E12, 210536.0], [1.53691896E12, 60789.0], [1.53691926E12, 162400.0], [1.5369189E12, 4908.0], [1.53691938E12, 105027.0], [1.5369192E12, 98689.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.53691902E12, 104950.0], [1.53691932E12, 77060.0], [1.53691914E12, 103156.0], [1.53691896E12, 60789.0], [1.53691926E12, 114298.0], [1.5369189E12, 4908.0], [1.53691938E12, 91228.0], [1.5369192E12, 81438.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.53691902E12, 104950.0], [1.53691932E12, 186372.0], [1.53691914E12, 200477.2], [1.53691896E12, 60789.0], [1.53691926E12, 189213.0], [1.5369189E12, 4908.0], [1.53691938E12, 181688.00000000003], [1.5369192E12, 197127.7]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.53691902E12, 104950.0], [1.53691932E12, 210169.84], [1.53691914E12, 210528.36], [1.53691896E12, 60789.0], [1.53691926E12, 210345.0], [1.5369189E12, 4908.0], [1.53691938E12, 210024.83000000002], [1.5369192E12, 210472.97]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.53691902E12, 104950.0], [1.53691932E12, 197297.4], [1.53691914E12, 207904.0], [1.53691896E12, 60789.0], [1.53691926E12, 201348.0], [1.5369189E12, 4908.0], [1.53691938E12, 196725.35], [1.5369192E12, 205122.15]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.53691938E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 93609.0, "minX": 0.0, "maxY": 146671.0, "series": [{"data": [[0.0, 93609.0], [1.0, 146671.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.create();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 93608.0, "minX": 0.0, "maxY": 146670.0, "series": [{"data": [[0.0, 93608.0], [1.0, 146670.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.05, "minX": 1.5369189E12, "maxY": 1.65, "series": [{"data": [[1.53691902E12, 0.4], [1.53691932E12, 0.05], [1.53691914E12, 1.65], [1.53691896E12, 1.0166666666666666], [1.53691926E12, 1.1], [1.5369189E12, 0.3], [1.5369192E12, 0.48333333333333334]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.53691932E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.5369189E12, "maxY": 1.6666666666666667, "series": [{"data": [[1.53691902E12, 0.016666666666666666], [1.53691932E12, 0.9666666666666667], [1.53691914E12, 1.6666666666666667], [1.53691896E12, 0.016666666666666666], [1.53691926E12, 1.1166666666666667], [1.5369189E12, 0.016666666666666666], [1.53691938E12, 0.7166666666666667], [1.5369192E12, 0.48333333333333334]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.53691938E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.5369189E12, "maxY": 1.6666666666666667, "series": [{"data": [[1.53691902E12, 0.016666666666666666], [1.53691932E12, 0.9666666666666667], [1.53691914E12, 1.6666666666666667], [1.53691896E12, 0.016666666666666666], [1.53691926E12, 1.1166666666666667], [1.5369189E12, 0.016666666666666666], [1.53691938E12, 0.7166666666666667], [1.5369192E12, 0.48333333333333334]], "isOverall": false, "label": "Get Premium-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.53691938E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 3600000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

// Collapse
$(function() {
        $('.collapse').on('shown.bs.collapse', function(){
            collapse(this, false);
        }).on('hidden.bs.collapse', function(){
            collapse(this, true);
        });
});

$(function() {
    $(".glyphicon").mousedown( function(event){
        var tmp = $('.in:not(ul)');
        tmp.parent().parent().parent().find(".fa-chevron-up").removeClass("fa-chevron-down").addClass("fa-chevron-down");
        tmp.removeClass("in");
        tmp.addClass("out");
    });
});

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "responseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    choiceContainer.find("label").each(function(){
        this.style.color = color;
    });
}

// Unchecks all boxes for "Hide all samples" functionality
function uncheckAll(id){
    toggleAll(id, false);
}

// Checks all boxes for "Show all samples" functionality
function checkAll(id){
    toggleAll(id, true);
}

// Prepares data to be consumed by plot plugins
function prepareData(series, choiceContainer, customizeSeries){
    var datasets = [];

    // Add only selected series to the data set
    choiceContainer.find("input:checked").each(function (index, item) {
        var key = $(item).attr("name");
        var i = 0;
        var size = series.length;
        while(i < size && series[i].label != key)
            i++;
        if(i < size){
            var currentSeries = series[i];
            datasets.push(currentSeries);
            if(customizeSeries)
                customizeSeries(currentSeries);
        }
    });
    return datasets;
}

/*
 * Ignore case comparator
 */
function sortAlphaCaseless(a,b){
    return a.toLowerCase() > b.toLowerCase() ? 1 : -1;
};

/*
 * Creates a legend in the specified element with graph information
 */
function createLegend(choiceContainer, infos) {
    // Sort series by name
    var keys = [];
    $.each(infos.data.result.series, function(index, series){
        keys.push(series.label);
    });
    keys.sort(sortAlphaCaseless);

    // Create list of series with support of activation/deactivation
    $.each(keys, function(index, key) {
        var id = choiceContainer.attr('id') + index;
        $('<li />')
            .append($('<input id="' + id + '" name="' + key + '" type="checkbox" checked="checked" hidden />'))
            .append($('<label />', { 'text': key , 'for': id }))
            .appendTo(choiceContainer);
    });
    choiceContainer.find("label").click( function(){
        if (this.style.color !== "rgb(129, 129, 129)" ){
            this.style.color="#818181";
        }else {
            this.style.color="black";
        }
        $(this).parent().children().children().toggleClass("legend-disabled");
    });
    choiceContainer.find("label").mousedown( function(event){
        event.preventDefault();
    });
    choiceContainer.find("label").mouseenter(function(){
        this.style.cursor="pointer";
    });

    // Recreate graphe on series activation toggle
    choiceContainer.find("input").click(function(){
        infos.createGraph();
    });
}
